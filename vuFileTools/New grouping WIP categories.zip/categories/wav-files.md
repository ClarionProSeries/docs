[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)

# WAV Files

- [vuMCISend](../functions/vuMCISend.md)
- [vuPlayWav](../functions/vuPlayWav.md)
- [vuRecordWav](../functions/vuRecordWav.md)

[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)