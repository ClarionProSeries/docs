[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)

# Interprocess Communications

- [vuMailSlotCheck](../functions/vuMailSlotCheck.md)
- [vuMailSlotCreate](../functions/vuMailSlotCreate.md)
- [vuMailSlotDestroy](../functions/vuMailSlotDestroy.md)
- [vuMailSlotDestroyAll](../functions/vuMailSlotDestroyAll.md)
- [vuMailSlotSend](../functions/vuMailSlotSend.md)

[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)