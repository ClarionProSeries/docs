
[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)

# vuFileTools - Functions Organized by Category

- [Desktop and Other Functions](./desktop-and-other-functions.md)
- [Drives and Storage](./drives-and-storage.md)
- [Email](./email.md)
- [Files and Folders](./files-and-folders.md)
- [Fonts](./fonts.md)
- [Interprocess Communications](./interprocess-communications.md)
- [Network Information](./network-information.md)
- [Printer Information](./printer-info.md)
- [Programs and Applications](./programs-and-applications.md)
- [Registry](./registry.md)
- [String Manipulation and Data Conversion](./string-manipulation-and-data-conversion.md)
- [System Information](./system-information.md)
- [WAV Files](./wav-files.md)
- [Windows Animation](./windows-animation.md)
- [Windows Information](./windows-information.md)
- [Windows Manipulation, Saving, and Printing](./windows-manipulation-saving-and-printing.md)

- [Compression](./compression.md)
- [Links and Reparse Points](./links-and-reparse-points.md)
- [Run and Shell](./run-and-shell.md)
- [Printing](./printing.md)
- [Drives and Volumes](./drives-and-volumes.md)
- [Startup Shortcuts and Autorun](./startup-shortcuts-and-autorun.md)
- [Elevation and Security](./elevation-and-security.md)
- [Network and System Checks](./network-and-system-checks.md)

[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)

