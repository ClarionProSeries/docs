[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)

# String Manipulation and Data Conversion

- [vuCRC32](../functions/vuCRC32.md)
- [vuNumber2String](../functions/vuNumber2String.md)
- [vuReplaceCharsInFile](../functions/vuReplaceCharsInFile.md)
- [vuStringParse](../functions/vuStringParse.md)

[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)