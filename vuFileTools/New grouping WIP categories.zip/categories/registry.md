[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)

# Registry

- [vuEZRegGet](../functions/vuEZRegGet.md)
- [vuEZRegPut](../functions/vuEZRegPut.md)
- [vuGetStartupItem](../functions/vuGetStartupItem.md)
- [vuWindowsKey](../functions/vuWindowsKey.md)

[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)