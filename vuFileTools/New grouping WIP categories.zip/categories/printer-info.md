[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)

# Printer Information

- [vuGetDefaultPrinter](../functions/vuGetDefaultPrinter.md)
- [vuPrintExists](../functions/vuPrintExists.md)
- [vuPrintExistsEx](../functions/vuPrintExistsEx.md)
- [vuPrintExistsShow](../functions/vuPrintExistsShow.md)
- [vuPrintScreen](../functions/vuPrintScreen.md)
- [vuPrintToExists](../functions/vuPrintToExists.md)
- [vuPrintToExistsEx](../functions/vuPrintToExistsEx.md)
- [vuPrinterCount](../functions/vuPrinterCount.md)
- [vuPrinterName](../functions/vuPrinterName.md)
- [vuSetDefaultPrinter](../functions/vuSetDefaultPrinter.md)

[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)