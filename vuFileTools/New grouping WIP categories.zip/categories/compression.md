[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)

# Compression

- [vuCompress](../functions/vuCompress.md)
- [vuCreateCompressedFolder](../functions/vuCreateCompressedFolder.md)
- [vuIsFolderCompressed](../functions/vuIsFolderCompressed.md)
- [vuIsNTFSCompressed](../functions/vuIsNTFSCompressed.md)
- [vuSetFolderCompression](../functions/vuSetFolderCompression.md)
- [vuSetNTFSCompression](../functions/vuSetNTFSCompression.md)
- [vuUncompress](../functions/vuUncompress.md)

[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)