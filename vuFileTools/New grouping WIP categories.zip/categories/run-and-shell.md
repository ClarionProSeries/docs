[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)

# Run and Shell

- [vuIsRunning](../functions/vuIsRunning.md)
- [vuIsRunningCheck](../functions/vuIsRunningCheck.md)
- [vuRun](../functions/vuRun.md)
- [vuRunDelay](../functions/vuRunDelay.md)
- [vuRunEx](../functions/vuRunEx.md)
- [vuRunExDelay](../functions/vuRunExDelay.md)
- [vuRunExists](../functions/vuRunExists.md)
- [vuRunExistsEx](../functions/vuRunExistsEx.md)
- [vuRunOnReboot](../functions/vuRunOnReboot.md)
- [vuShell](../functions/vuShell.md)
- [vuShellDelay](../functions/vuShellDelay.md)
- [vuShellEx](../functions/vuShellEx.md)
- [vuShellExDelay](../functions/vuShellExDelay.md)

[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)