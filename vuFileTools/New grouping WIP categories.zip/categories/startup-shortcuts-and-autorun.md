[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)

# Startup Shortcuts and Autorun

- [vuAddStartupShortcut](../functions/vuAddStartupShortcut.md)
- [vuEnumerateStartupItems](../functions/vuEnumerateStartupItems.md)
- [vuGetStartupFolder](../functions/vuGetStartupFolder.md)
- [vuGetStartupItem](../functions/vuGetStartupItem.md)
- [vuRemoveStartupShortcut](../functions/vuRemoveStartupShortcut.md)

[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)