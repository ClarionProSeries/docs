[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)

# System Information

- [vuBIOSSerialNo](../functions/vuBIOSSerialNo.md)
- [vuBatteryLife](../functions/vuBatteryLife.md)
- [vuCPUMake](../functions/vuCPUMake.md)
- [vuCPUSerialNo](../functions/vuCPUSerialNo.md)
- [vuCPUSpeed](../functions/vuCPUSpeed.md)
- [vuCPUusage](../functions/vuCPUusage.md)
- [vuComputerName](../functions/vuComputerName.md)
- [vuElevationType](../functions/vuElevationType.md)
- [vuIsElevated](../functions/vuIsElevated.md)
- [vuMACCount](../functions/vuMACCount.md)
- [vuMemoryFree](../functions/vuMemoryFree.md)
- [vuMemoryPercentUsed](../functions/vuMemoryPercentUsed.md)
- [vuMemoryTotal](../functions/vuMemoryTotal.md)
- [vuOSVersion](../functions/vuOSVersion.md)
- [vuProcessorCount](../functions/vuProcessorCount.md)
- [vuServerTZOffset](../functions/vuServerTZOffset.md)

[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)