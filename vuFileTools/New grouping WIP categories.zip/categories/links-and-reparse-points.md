[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)

# Links and Reparse Points

- [vuCreateHardLink](../functions/vuCreateHardLink.md)
- [vuCreateJunction](../functions/vuCreateJunction.md)
- [vuCreateLink](../functions/vuCreateLink.md)
- [vuCreateLinkEx](../functions/vuCreateLinkEx.md)
- [vuCreateSymbolicLink_Dir](../functions/vuCreateSymbolicLink_Dir.md)
- [vuCreateSymbolicLink_File](../functions/vuCreateSymbolicLink_File.md)
- [vuPrimaryLinkSpeed](../functions/vuPrimaryLinkSpeed.md)

[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)