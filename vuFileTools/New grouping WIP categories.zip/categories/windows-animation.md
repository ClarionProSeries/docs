[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)

# Windows Animation

- [vuAnimateCloseBlend](../functions/vuAnimateCloseBlend.md)
- [vuAnimateCloseCenter](../functions/vuAnimateCloseCenter.md)
- [vuAnimateCloseRoll](../functions/vuAnimateCloseRoll.md)
- [vuAnimateCloseSlide](../functions/vuAnimateCloseSlide.md)
- [vuAnimateOpenBlend](../functions/vuAnimateOpenBlend.md)
- [vuAnimateOpenCenter](../functions/vuAnimateOpenCenter.md)
- [vuAnimateOpenRoll](../functions/vuAnimateOpenRoll.md)
- [vuAnimateOpenSlide](../functions/vuAnimateOpenSlide.md)

[Home](../index.md) | [All functions](../functions/index.md) | [Categories](index.md)